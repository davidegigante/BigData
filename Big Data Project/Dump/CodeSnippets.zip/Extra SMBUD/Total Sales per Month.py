import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

shopping_cart_data = pd.read_csv('shoppingCart.csv')

shopping_cart_data['Sales'] = shopping_cart_data['Avg_Price'] * shopping_cart_data['Quantity']

# Summing up total sales for each month
total_sales_per_month = shopping_cart_data.groupby('Month')['Sales'].sum()

# Create a list of colors, one for each month
# Adjust the number in np.linspace() according to the number of unique months in your dataset
colors = plt.cm.viridis(np.linspace(0, 1, len(total_sales_per_month)))

# Plotting the histogram (bar plot)
plt.figure(figsize=(10, 6))
total_sales_per_month.plot(kind='bar', color=colors)

plt.title('Total Sales per Month')
plt.xlabel('Month')
plt.ylabel('Total Sales')
plt.xticks(rotation=45)  # Rotate x-axis labels for better readability
plt.grid(True)
plt.show()
