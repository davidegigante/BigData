import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

# Load your dataset
shopping_cart_data = pd.read_csv('shoppingCart.csv')

shopping_cart_data['Sales'] = shopping_cart_data['Avg_Price'] * shopping_cart_data['Quantity']

# Grouping the data by Month and Gender
# Assuming 'Gender' column has values like 'Male' and 'Female'
sales_by_month_gender = shopping_cart_data.groupby(['Month', 'Gender'])['Sales'].sum().unstack()

# Plotting
plt.figure(figsize=(12, 6))
sales_by_month_gender.plot(kind='bar', color={'M': 'blue', 'F': 'pink'})

plt.title('Monthly Sales Split by Gender')
plt.xlabel('Month')
plt.ylabel('Total Sales')
plt.xticks(rotation=45)  # Rotate x-axis labels for better readability
plt.grid(True)
plt.legend(title='Gender')
plt.show()
