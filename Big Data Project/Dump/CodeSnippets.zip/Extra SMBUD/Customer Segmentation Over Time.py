import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

# Load the data
shopping_cart_data = pd.read_csv('shoppingCart.csv')

# Define a function to categorize tenure
def categorize_tenure(tenure):
    if tenure <= 6:
        return '0-6 months'
    elif tenure <= 12:
        return '7-12 months'
    elif tenure <= 24:
        return '1-2 years'
    else:
        return '2+ years'

# Apply the function to create a new column
shopping_cart_data['Tenure_Category'] = shopping_cart_data['Tenure_Months'].apply(categorize_tenure)

# Customer Segmentation Over Time
tenure_distribution = shopping_cart_data['Tenure_Category'].value_counts()
tenure_distribution.plot(kind='bar')
plt.title('Customer Segmentation Over Time')
plt.xlabel('Tenure Category')
plt.xticks(rotation=45)  # Rotate x-axis labels for better readability
plt.grid(True)
plt.ylabel('Number of Customers')
plt.show()
