import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

shoppingCart = pd.read_csv('shoppingCart.csv')

shoppingCart['Transaction_Date'] = pd.to_datetime(shoppingCart['Transaction_Date'])

shoppingCart['Effective_Price'] = shoppingCart.apply(
    lambda row: row['Avg_Price'] * (1 - row['Discount_pct'] / 100) if row['Coupon_Status'] == 'Used' else row['Avg_Price'], axis=1
)

plt.figure(figsize=(10, 6))
sns.boxplot(x='Gender', y='Effective_Price', data=shoppingCart)
plt.title('Distribution of Total Spending by Gender')
plt.xlabel('Gender')
plt.ylabel('Effective Price')
plt.show()

