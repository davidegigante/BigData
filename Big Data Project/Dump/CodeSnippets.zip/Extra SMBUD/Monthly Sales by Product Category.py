import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

shopping_cart_data = pd.read_csv('shoppingCart.csv')

# First, we need to aggregate the data to get monthly sales for each product category
# Assuming 'Avg_Price' * 'Quantity' gives the sales value
# Also assuming 'Month' is in a format that can be sorted chronologically (e.g., 'January', 'February', etc.)

# Calculate sales
shopping_cart_data['Sales'] = shopping_cart_data['Avg_Price'] * shopping_cart_data['Quantity']

# Group by Month and Product_Category and sum up the sales
monthly_sales = shopping_cart_data.groupby(['Month', 'Product_Category'])['Sales'].sum().unstack()

# Plotting
plt.figure(figsize=(12, 6))
for category in monthly_sales.columns:
    plt.plot(monthly_sales.index, monthly_sales[category], label=category)

plt.title('Monthly Sales by Product Category')
plt.xlabel('Month')
plt.ylabel('Sales')
plt.legend(loc='upper left', bbox_to_anchor=(1, 1))
plt.grid(True)
plt.tight_layout()
plt.show()
