import sys
import os
from flask import Flask, render_template, request, jsonify
import subprocess

app = Flask(__name__)

python_executable = sys.executable

app_folder = os.path.dirname(os.path.abspath(__file__))

@app.route('/')
def index():
    files = [
        "Average Spending Trends by Customer Tenure.py",
        "Customer Segmentation Over Time.py",
        "Distribution of Total Spending by Gender.py",
        "Monthly Sales by Product Category.py",
        "Monthly Sales Split by Gender.py",
        "Total Monthly Spending Trend.py",
        "Total Sales per Month.py"
    ]
    return render_template('index.html', files=files, message="")

@app.route('/run_code', methods=['POST'])
def run_code():
    selected_file = request.form['selected_file']
    if selected_file:
        try:
            full_path = os.path.join(app_folder, selected_file)
            if os.path.exists(full_path):
                subprocess.Popen([python_executable, full_path])
                return jsonify({'success': True})
            else:
                return jsonify({'success': False, 'error_message': 'File not found.'})
        except Exception as e:
            return jsonify({'success': False, 'error_message': str(e)})
    return jsonify({'success': False, 'error_message': 'No file chosen.'})

if __name__ == '__main__':
    app.run(debug=True)
