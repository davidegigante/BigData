import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

shoppingCart = pd.read_csv('shoppingCart.csv')

shoppingCart['Transaction_Date'] = pd.to_datetime(shoppingCart['Transaction_Date'])

shoppingCart['Effective_Price'] = shoppingCart.apply(
    lambda row: row['Avg_Price'] * (1 - row['Discount_pct'] / 100) if row['Coupon_Status'] == 'Used' else row['Avg_Price'], axis=1
)

monthly_spending = shoppingCart.groupby(shoppingCart['Transaction_Date'].dt.to_period('M')).agg({'Effective_Price': 'sum'}).reset_index()
monthly_spending['Transaction_Date'] = monthly_spending['Transaction_Date'].dt.to_timestamp()

plt.figure(figsize=(12, 6))
sns.lineplot(x='Transaction_Date', y='Effective_Price', data=monthly_spending)
plt.title('Total Monthly Spending Trend')
plt.xlabel('Month')
plt.ylabel('Total Spending')
plt.xticks(rotation=45)
plt.show()